﻿select * from tblProducts

