﻿select * from dbo.tblProducts
