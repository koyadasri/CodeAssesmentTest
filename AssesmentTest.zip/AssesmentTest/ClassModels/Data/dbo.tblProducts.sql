﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(50) NULL, 
    [Brand] VARCHAR(50) NULL, 
    [Price] INT NULL, 
    [Quantity] INT NULL
)
