﻿namespace AssesmentTest.Services
{
    public class ApiResponse
    {
        public string? Api1Response { get; set; }
        public string? Api2Response { get; set; }

    }
}
