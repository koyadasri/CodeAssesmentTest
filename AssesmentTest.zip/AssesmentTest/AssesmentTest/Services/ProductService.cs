﻿using DataModels.Models;

namespace AssesmentTest.Services
{
    public class ProductService : IProductService
    {
        private const string RequestUri = "api/product/";
        private readonly HttpClient _httpClient;

        public ProductService(HttpClient httpClient)
        {
            this._httpClient = httpClient;
        }
        public async Task<IEnumerable<Product>> GetProducts() => await _httpClient.GetFromJsonAsync<Product[]>(requestUri: RequestUri);
         
    }
}
