﻿using DataModels.Models;

namespace AssesmentTest.Services
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetProducts();
    }
}
