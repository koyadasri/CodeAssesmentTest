﻿namespace BlazorAppUI.Services
{
    public interface IApiService
    {
    }
}
